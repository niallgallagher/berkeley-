package javaapp6;

import com.mongodb.client.ClientSession;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.TransactionBody;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.or;
import static com.mongodb.client.model.Updates.addToSet;
import static com.mongodb.client.model.Updates.addEachToSet;

import org.bson.Document;

import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JavaApp6 {
    private static MongoClient c = null;
    private static MongoDatabase db3 = null;
    private static ClientSession s = null;
    private static MongoCollection<Document> authors = null, books = null;

    public static void main(String[] args) {
        Logger.getLogger("org.mongodb.driver").setLevel(Level.SEVERE);
        
        try {
            // NOTE : Setup !
            c = MongoClients.create("mongodb+srv://GlynH:eAOwBAvepCrlaGMk@clusterglynh.fiz0ewt.mongodb.net/test");
            db3 = c.getDatabase("db3");
            s = c.startSession();

            authors = db3.getCollection("authors");
            books = db3.getCollection("books");

            s.startTransaction();

            authors.updateOne(s,
                    eq("_id", 9),
                    addEachToSet("books", Arrays.asList(1, 2))
            );

            books.updateMany(s,
                    or(eq("_id", 1), eq("_id", 2)),
                    addToSet("authors", 9)
            );

            // s.commitTransaction();
            s.abortTransaction();         

            /*
            TransactionBody tB = new TransactionBody<String>() {
                @Override
                public String execute() {
                    authors.updateOne(s,
                        eq("_id", 9),
                        addEachToSet("books", Arrays.asList(1, 2))
                    );

                    books.updateMany(s,
                        or(eq("_id", 1), eq("_id", 2)),
                        addToSet("authors", 9)
                    );

                    return ":)";
                }
            };

            s.withTransaction(tB);
            */

            System.out.println("Bye Bye :)");
        }
        catch (Exception e) {
            // System.err.println(e.getMessage());
        }
        finally {
            s.close();
            c.close();
        }
    }
}
